// ESCONDE A PAGINA DE RASTREIO

$('#rastreio-page').hide();